# TransitOps — Product Requirements Document (PRD)

**Version:** 1.0
**Date:** July 12, 2026
**Project Type:** 8-Hour Hackathon Build
**Document Owner:** Project Team

---

## 1. Executive Summary

TransitOps is a centralized, role-based transport operations platform that digitizes the full lifecycle of fleet management — vehicle registration, driver management, trip dispatching, maintenance, fuel/expense tracking, and analytics — for logistics organizations currently relying on spreadsheets and manual logbooks.

Unlike traditional transport ERP tools (e.g., eCount Transport), which are **accounting-first** systems built around freight billing (LR/GR entries, hire receipts, GST invoicing), TransitOps is **operations-first**: it treats the vehicle and driver as live, rule-governed state machines. The system actively prevents invalid operational states (overloaded cargo, expired licenses, double-booked assets) at the moment of action, rather than surfacing errors later in an accounting reconciliation.

---

## 2. Problem Statement

Logistics companies managing fleets via spreadsheets and manual logbooks routinely face:
- Scheduling conflicts (double-booking a vehicle or driver already on a trip)
- Underutilized vehicles due to lack of real-time visibility
- Missed maintenance windows, leading to breakdowns and safety risk
- Expired driver licenses going undetected until an incident occurs
- Inaccurate or delayed expense/fuel tracking
- No consolidated view of per-vehicle profitability (ROI)

---

## 3. Goals & Objectives

| Goal | Description |
|---|---|
| Centralize fleet data | Single source of truth for vehicles, drivers, trips, maintenance, and expenses |
| Enforce business rules automatically | Prevent invalid dispatches, overloaded cargo, expired-license assignments |
| Real-time operational visibility | Live dashboard reflecting current fleet/driver/trip state |
| Role-based access | Each user role sees only what's relevant to their job function |
| Operational + financial insight | Fleet utilization, fuel efficiency, operational cost, and per-vehicle ROI in one view |

---

## 4. Competitive Positioning

### 4.1 How TransitOps differs from existing tools (e.g., eCount Transport)

eCount Transport and similar Indian TMS products are built around **LR/GR (Lorry Receipt) entry, hire receipts, freight billing, and GST-compliant invoicing** — they are transport *accounting* software with trip logging bolted on, aimed at cargo/full-load transport contractors and fleet owners.

TransitOps is different in kind, not just in UI polish:

| Dimension | eCount-style TMS | TransitOps |
|---|---|---|
| Core data unit | Invoice / Lorry Receipt | Vehicle & Driver state machine |
| Rule enforcement | Manual, discovered post-hoc during accounting | Automated, blocks invalid actions at entry (capacity, license, status) |
| Access control | Basic user login | 4 distinct roles with scoped dashboards (RBAC) |
| Fleet visibility | Static reports | Live status board (Available / On Trip / In Shop / Retired) |
| Analytics | GST & financial ledgers | Fleet utilization %, fuel efficiency, operational cost, per-vehicle ROI |
| Workflow automation | Manual status updates | Status transitions triggered automatically by trip/maintenance events |

### 4.2 Unique Selling Proposition (USP)

> **"eCount tells you what you billed. TransitOps tells you what your fleet is doing right now — and stops mistakes before they happen."**

Concrete differentiators to emphasize in the demo/pitch:
1. **Rule-enforced dispatch** — cargo capacity, license validity, and asset availability are validated at the moment of dispatch, not after the fact.
2. **Single-source vehicle/driver state** — status is a derived, workflow-driven field (dispatch → On Trip, complete → Available, maintenance → In Shop), never manually toggled.
3. **Per-vehicle ROI**, not just per-trip revenue — ties acquisition cost, fuel, and maintenance into one profitability metric most desktop TMS tools don't expose.
4. **Role-scoped dashboards** reduce noise: a Safety Officer sees compliance data only; a Financial Analyst sees cost/ROI only; a Dispatcher sees live trip boards only.

---

## 5. Target Users & Personas

| Role | Responsibilities | Primary Screens |
|---|---|---|
| **Fleet Manager** | Oversees fleet assets, maintenance, vehicle lifecycle, operational efficiency | Dashboard, Fleet (Vehicle Registry), Maintenance |
| **Dispatcher** | Creates trips, assigns vehicles/drivers, monitors active deliveries | Dashboard, Trips (Trip Dispatcher) |
| **Safety Officer** | Ensures driver compliance, tracks license validity, monitors safety scores | Drivers, Compliance views |
| **Financial Analyst** | Reviews operational expenses, fuel consumption, maintenance costs, profitability | Fuel & Expenses, Analytics |

RBAC access is enforced per the matrix in Section 8.

---

## 6. Functional Requirements

### 6.1 Authentication
- Email + password login.
- Role-Based Access Control (RBAC) — access scoped by role post-login.
- Only authenticated users can access any part of the application.
- Invalid credential and account-lockout states must be handled (per wireframe: lockout after 5 failed attempts).

### 6.2 Dashboard
- KPI tiles: Active Vehicles, Available Vehicles, Vehicles in Maintenance, Active Trips, Pending Trips, Drivers on Duty, Fleet Utilization (%).
- Filters: Vehicle Type, Status, Region.
- Recent Trips table (Trip ID, Vehicle, Driver, Status, ETA).
- Vehicle Status breakdown bar (Available / On Trip / In Shop / Retired).

### 6.3 Vehicle Registry
- Fields: Registration Number (**unique**), Vehicle Name/Model, Type, Max Load Capacity, Odometer, Acquisition Cost, Status.
- Status values: `Available`, `On Trip`, `In Shop`, `Retired`.
- Add/Edit/Search/Filter by type, status.
- Rule: registration number uniqueness enforced at entry; Retired/In Shop vehicles hidden from Trip Dispatcher's vehicle pool.

### 6.4 Driver Management
- Fields: Name, License Number, License Category, License Expiry Date, Contact Number, Safety Score (%), Status.
- Status values: `Available`, `On Trip`, `Off Duty`, `Suspended`.
- Rule: expired license or Suspended status blocks the driver from trip assignment (enforced in Trip Dispatcher).

### 6.5 Trip Management (Trip Dispatcher)
- Create trip: Source, Destination, Vehicle (available only), Driver (available only), Cargo Weight, Planned Distance.
- Trip lifecycle: `Draft → Dispatched → Completed → Cancelled`.
- Live board showing all trips grouped by current lifecycle stage.
- Validation: Cargo Weight ≤ Vehicle Max Load Capacity (blocks dispatch otherwise, with explicit error message).
- Dispatch action: sets Vehicle & Driver status → `On Trip`.
- Complete action: requires final odometer + fuel consumed; sets Vehicle & Driver status → `Available`; feeds Fuel Log and Vehicle odometer.
- Cancel action (from Dispatched): restores Vehicle & Driver → `Available`.

### 6.6 Maintenance
- Log Service Record: Vehicle, Service Type, Cost, Date, Status (`Active`/`Completed`).
- Creating an active maintenance record → Vehicle status auto-changes to `In Shop`, removed from dispatch pool.
- Closing/completing maintenance → Vehicle restored to `Available` (unless Retired).
- Service Log table: history per vehicle (Service, Cost, Status).

### 6.7 Fuel & Expense Management
- Fuel Logs: Vehicle, Date, Liters, Cost.
- Other Expenses: Trip, Vehicle, Toll, Other, Maintenance (linked), Total, Status.
- Auto-computed **Total Operational Cost = Fuel + Maintenance** per vehicle and fleet-wide.

### 6.8 Reports & Analytics
- KPIs: Fuel Efficiency (Distance / Fuel, km/l), Fleet Utilization (%), Operational Cost, Vehicle ROI.
- ROI formula: `ROI = (Revenue − (Maintenance + Fuel)) / Acquisition Cost`
- Monthly Revenue trend chart.
- Top Costliest Vehicles ranking (bar chart).
- CSV export (mandatory). PDF export (optional/bonus).

### 6.9 Settings & RBAC
- General settings: Depot Name, Currency, Distance Unit.
- Role-based access control matrix (view/edit/no-access) per module, editable by admin/Fleet Manager.

---

## 7. Mandatory Business Rules (must be enforced in code, not just UI hints)

1. Vehicle registration number must be unique.
2. Retired or In Shop vehicles must never appear in the dispatch (Trip Dispatcher) selection pool.
3. Drivers with expired licenses or Suspended status cannot be assigned to trips.
4. A driver or vehicle already marked `On Trip` cannot be assigned to another trip.
5. Cargo Weight must not exceed the vehicle's maximum load capacity — dispatch is blocked otherwise.
6. Dispatching a trip automatically changes both vehicle and driver status to `On Trip`.
7. Completing a trip automatically changes both vehicle and driver status back to `Available`.
8. Cancelling a dispatched trip restores vehicle and driver to `Available`.
9. Creating an active maintenance record automatically changes vehicle status to `In Shop`.
10. Closing maintenance restores the vehicle to `Available` (unless it is Retired).

These rules are the core evaluation criteria for the hackathon — they must be demonstrable live, not just described.

---

## 8. RBAC Access Matrix

| Module | Fleet Manager | Dispatcher | Safety Officer | Financial Analyst |
|---|---|---|---|---|
| Dashboard | ✅ Full | ✅ Full | View | View |
| Fleet (Vehicles) | ✅ Full | View | — | — |
| Drivers | ✅ Full | View | ✅ Full | — |
| Trips | ✅ Full | ✅ Full | — | View |
| Maintenance | ✅ Full | — | — | View |
| Fuel & Expenses | ✅ Full | — | — | ✅ Full |
| Analytics | ✅ Full | View | View | ✅ Full |
| Settings | ✅ Full | — | — | — |

*(Matches wireframe screen 8 — "✓" = full access, "View" = read-only, "—" = no access.)*

---

## 9. Non-Functional Requirements

- Responsive web UI (desktop-first, usable on tablet).
- Page load / interaction response under 1–2 seconds for a hackathon-scale dataset (tens of vehicles/drivers/trips).
- All mandatory business rules enforced server-side (not just client-side validation), so they can't be bypassed via direct API calls.
- Session-based authentication; unauthenticated users redirected to login.
- Data persisted (no in-memory-only demo) — SQLite file-based DB.

---

## 10. Scope

### 10.1 In Scope (Core / Mandatory Deliverables)
- Responsive web interface
- Authentication with RBAC
- CRUD for Vehicles and Drivers
- Trip Management with all validations in Section 7
- Automatic status transitions (vehicle/driver)
- Maintenance workflow
- Fuel & Expense tracking with auto cost computation
- Dashboard with KPIs
- Charts and visual analytics (Chart.js/Recharts)
- CSV export

### 10.2 Stretch Goals (Bonus, time-permitting — attempt in this order)
Given the 1–2 person team and 8-hour window, bonus features are prioritized by effort-to-impact ratio:

1. **Dark mode** (low effort, high visual impact for demo) — CSS variable theme toggle.
2. **Search, filters, and sorting** (already partially required by core screens — extend to all tables).
3. **Email reminders for expiring licenses** (moderate effort — a scheduled/on-load check + a mock or real email trigger; can be simulated as an in-app banner if time runs out).
4. **PDF export** (moderate effort using a client-side lib like `jspdf` or `@react-pdf/renderer`).
5. **Vehicle document management** (file upload/storage — only if time remains; treat as lowest priority).

*If time is tight at hour 6, cut from the bottom of this list first.*

### 10.3 Out of Scope
- Route optimization / GPS live tracking (not in original spec)
- Multi-tenant/multi-depot support beyond the Settings "Depot Name" field
- Mobile native apps
- Third-party accounting/GST integration

---

## 11. Example End-to-End Workflow (acceptance test script)

1. Register vehicle "Van-05", max capacity 500 kg → status `Available`.
2. Register driver "Alex" with a valid (non-expired) license.
3. Create trip: Cargo Weight = 450 kg.
4. System validates 450 kg ≤ 500 kg → dispatch allowed.
5. Vehicle and Driver status auto-update to `On Trip`.
6. Complete trip: enter final odometer + fuel consumed.
7. Vehicle and Driver revert to `Available`; odometer and fuel log update.
8. Create maintenance record ("Oil Change") → vehicle status → `In Shop`, hidden from dispatch.
9. Reports/Analytics update: operational cost and fuel efficiency reflect the new trip and fuel log.

This script should be run live as the primary demo flow.

---

## 12. Database Entities (high-level)

`Users`, `Roles`, `Vehicles`, `Drivers`, `Trips`, `MaintenanceLogs`, `FuelLogs`, `Expenses`

(Full schema in the Design Document, Section: Data Model.)

---

## 13. Success Metrics (for hackathon judging)

- All 10 mandatory business rules demonstrably enforced live.
- Full workflow (Section 11) completes without manual DB edits.
- Dashboard and Analytics reflect real-time state after each action (no stale data / no manual refresh required beyond standard page navigation).
- RBAC correctly restricts at least 2 distinct roles' views in the live demo.
- At least 1 chart-based analytics view (Monthly Revenue or Top Costliest Vehicles) rendering real data.

---

## 14. Assumptions & Constraints

- Single depot/organization context for this build (multi-depot is a Settings field only, not enforced logic).
- Seed/demo data will be pre-loaded to make the 8-hour demo compelling (a handful of vehicles, drivers, and trips in varied states).
- SQLite used for simplicity; not intended to reflect final production database choice.
- Email reminders (if attempted) may be simulated rather than sent via a real SMTP provider, given time constraints.
