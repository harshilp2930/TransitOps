# TransitOps — Tech Stack Document

**Version:** 1.0
**Date:** July 12, 2026
**Context:** 8-hour hackathon build, team of 1–2, SQLite chosen for speed.

---

## 1. Recommendation Summary

Drop the two-app Django + Next.js split. Use a **single Next.js full-stack application**. Rationale: with 1–2 people and 8 hours, every hour spent wiring CORS, two auth systems, or two deploy targets is an hour not spent on business rules (the actual judged criteria). One repo also means one person can build a full vertical slice (UI + logic + DB) per feature without waiting on the other.

Skip **pandas** — none of the analytics in this spec (fuel efficiency, utilization %, operational cost, ROI) need a dataframe library; they're simple SQL aggregations (`SUM`, `COUNT`, `AVG`) that Prisma/SQL handles directly and faster.

---

## 2. Final Stack

| Layer | Choice | Why |
|---|---|---|
| Framework | **Next.js 14+ (App Router)** | Single app for UI + API; Server Components + Server Actions reduce boilerplate |
| Language | **TypeScript** | Catches shape mismatches between form data and DB schema fast — valuable when time is tight |
| Styling | **Tailwind CSS** | Fastest way to hit the dashboard/table-heavy look in the wireframe without hand-writing CSS |
| ORM | **Prisma** | Type-safe queries, quick migrations, works great with SQLite |
| Database | **SQLite** (via Prisma) | Zero setup — a file, no server to run; fine for hackathon scale and demo |
| Auth | **NextAuth.js (Credentials provider)** *or* a minimal custom cookie+JWT session if NextAuth setup eats too much time | Session-based login with role stored on the JWT/session; role checked in middleware |
| Charts | **Recharts** (or Chart.js if team has prior experience with it) | React-native charting, works well with Tailwind, minimal setup for bar/line charts |
| Forms | **react-hook-form** (optional) | Speeds up the many CRUD forms (Vehicle, Driver, Trip, Maintenance, Fuel/Expense) |
| CSV Export | **papaparse** or native `Blob` + CSV string builder | Mandatory deliverable — keep it simple, client-side generation from already-fetched data |
| PDF Export (bonus) | **jspdf** or **@react-pdf/renderer** | Only attempt if core features are done with time to spare |
| Deployment (demo) | **Local + Vercel** (push to Vercel for a live judge-accessible URL) or just `npm run dev` on localhost if offline demo is acceptable | Vercel deploy of a Next.js + SQLite app needs the SQLite file bundled or swapped to a hosted Postgres (e.g. Neon) at deploy time — decide this by hour 6 at the latest |

> **Deployment note:** SQLite works great locally but Vercel's serverless functions have an ephemeral filesystem — a SQLite file won't persist across deployments/requests reliably in production. For a **live hosted demo**, swap the Prisma datasource to a free-tier hosted Postgres (Neon, Supabase) in the last hour — the Prisma schema barely changes (just the `provider` and `DATABASE_URL`). If the demo will be run **locally on the presenter's machine**, SQLite is fine as-is with zero changes.

---

## 3. Project Structure (suggested)

```
transitops/
├── prisma/
│   └── schema.prisma
├── src/
│   ├── app/
│   │   ├── (auth)/login/page.tsx
│   │   ├── dashboard/page.tsx
│   │   ├── fleet/page.tsx              # Vehicle Registry
│   │   ├── drivers/page.tsx
│   │   ├── trips/page.tsx              # Trip Dispatcher
│   │   ├── maintenance/page.tsx
│   │   ├── fuel-expenses/page.tsx
│   │   ├── analytics/page.tsx
│   │   ├── settings/page.tsx
│   │   └── api/
│   │       └── ...route.ts (if not using Server Actions)
│   ├── components/
│   │   ├── ui/ (badges, tables, cards, sidebar, topbar)
│   │   └── charts/
│   ├── lib/
│   │   ├── rules.ts        # centralized business rule validators (PRD §7)
│   │   ├── auth.ts         # NextAuth config / session helpers
│   │   ├── db.ts           # Prisma client singleton
│   │   └── analytics.ts    # ROI, utilization, fuel-efficiency calculations
│   └── middleware.ts        # route-level RBAC guard
├── .env                      # DATABASE_URL, NEXTAUTH_SECRET
└── package.json
```

---

## 4. Core Dependencies

```bash
npx create-next-app@latest transitops --typescript --tailwind --app
cd transitops
npm install prisma @prisma/client
npm install next-auth
npm install recharts
npm install react-hook-form
npm install papaparse
npx prisma init --datasource-provider sqlite
```

---

## 5. Why Not Django + Next.js (for this specific context)

Django + DRF is a genuinely strong stack for larger, longer-running projects with a bigger team where backend/frontend can be built in parallel by different people. For this project specifically:
- Team is 1–2 people → no parallelization benefit from splitting frontend/backend.
- 8-hour window → auth token exchange between Django and Next.js, CORS config, and two separate `npm run dev` / `python manage.py runserver` processes cost setup time with no payoff.
- The business rules (PRD §7) are simple conditional checks, not something that benefits from Django's ORM/admin/ecosystem.
- pandas is unnecessary overhead for aggregate SUM/AVG queries at this scale.

If the team is significantly more comfortable in Django than Next.js API routes, it's still a workable choice — just budget extra time for the integration seam and drop pandas regardless.

---

## 6. Suggested 8-Hour Build Timeline

| Hour | Focus |
|---|---|
| 0–1 | Scaffold Next.js app, Prisma schema (all entities from Design Doc §2), seed script with demo data |
| 1–2 | Auth (login, session, RBAC middleware), sidebar/topbar shell |
| 2–3 | Vehicle Registry + Driver Management CRUD |
| 3–4.5 | Trip Dispatcher (create/dispatch/complete/cancel) + all validation rules — **highest priority, most judged** |
| 4.5–5.5 | Maintenance workflow + Fuel/Expense logging (with cost auto-computation) |
| 5.5–6.5 | Dashboard KPIs + Analytics charts (ROI, utilization, fuel efficiency) + CSV export |
| 6.5–7.5 | Bonus features if time allows (dark mode → filters/sorting polish → license expiry reminders) |
| 7.5–8 | Bug pass, seed data sanity check, rehearse the demo script from PRD §11 |

---

## 7. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Business rule bugs found late | Write `lib/rules.ts` validators first and unit-test mentally against PRD §11 script before building UI around them |
| SQLite file not persisting on serverless deploy | Decide demo mode (local vs hosted) by hour 6; switch to Neon/Supabase Postgres only if hosted demo is required |
| Scope creep into bonus features before core is done | Hard rule: no bonus feature work starts before all of PRD §10.1 (core scope) passes the §11 acceptance script |
| Auth setup taking too long | Fall back to a minimal custom cookie-based session (store `userId` + `role` in a signed cookie) if NextAuth config stalls past 45 minutes |
