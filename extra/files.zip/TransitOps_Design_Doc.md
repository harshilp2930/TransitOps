# TransitOps — Design Document

**Version:** 1.0
**Date:** July 12, 2026
**Companion documents:** TransitOps_PRD.md, TransitOps_TechStack.md

---

## 1. System Architecture Overview

Single Next.js application (monolith) serving both UI and API, backed by SQLite via Prisma. No separate backend service — this keeps the 1–2 person team working in one repo with no cross-service auth/CORS overhead.

```
┌─────────────────────────────────────────────┐
│                Next.js App                    │
│                                               │
│  ┌───────────────┐      ┌──────────────────┐ │
│  │  App Router    │      │   API Routes /    │ │
│  │  Pages (UI)    │◄────►│  Server Actions    │ │
│  │  React + Tailwind      │  (business logic) │ │
│  └───────────────┘      └─────────┬────────┘ │
│                                    │           │
│                          ┌─────────▼────────┐ │
│                          │   Prisma ORM      │ │
│                          └─────────┬────────┘ │
│                                    │           │
│                          ┌─────────▼────────┐ │
│                          │  SQLite (file DB) │ │
│                          └──────────────────┘ │
└─────────────────────────────────────────────┘
```

- **Auth**: session-based (NextAuth Credentials provider, or a lightweight custom JWT-in-cookie if NextAuth setup overhead isn't worth it) — role stored on the User record, checked in middleware and on every server action/API route.
- **Business rule enforcement**: all 10 mandatory rules (PRD §7) live in a single `lib/rules.ts` module, called from server actions before any DB write — never trusted to the client.
- **Charts**: rendered client-side with Recharts (or Chart.js), fed by API routes that return aggregated JSON.

---

## 2. Data Model (ERD)

### 2.1 Entities & Fields

**User**
- id, name, email (unique), passwordHash, role (`FLEET_MANAGER` | `DISPATCHER` | `SAFETY_OFFICER` | `FINANCIAL_ANALYST`), createdAt

**Vehicle**
- id, registrationNumber (unique), name, model, type (`Van`|`Truck`|`Mini`|...), maxLoadCapacityKg, odometerKm, acquisitionCost, status (`AVAILABLE`|`ON_TRIP`|`IN_SHOP`|`RETIRED`), region, createdAt

**Driver**
- id, name, licenseNumber, licenseCategory, licenseExpiryDate, contactNumber, safetyScore, status (`AVAILABLE`|`ON_TRIP`|`OFF_DUTY`|`SUSPENDED`), createdAt

**Trip**
- id, tripCode, source, destination, vehicleId (FK), driverId (FK), cargoWeightKg, plannedDistanceKm, status (`DRAFT`|`DISPATCHED`|`COMPLETED`|`CANCELLED`), dispatchedAt, completedAt, finalOdometerKm, fuelConsumedLiters, createdAt

**MaintenanceLog**
- id, vehicleId (FK), serviceType, cost, date, status (`ACTIVE`|`COMPLETED`), createdAt

**FuelLog**
- id, vehicleId (FK), tripId (FK, nullable), date, liters, cost, createdAt

**Expense**
- id, tripId (FK, nullable), vehicleId (FK), tollCost, otherCost, maintenanceLinked, total (computed), status, date

### 2.2 Relationships
- Vehicle 1—N Trip
- Driver 1—N Trip
- Vehicle 1—N MaintenanceLog
- Vehicle 1—N FuelLog
- Trip 1—N FuelLog (a completed trip logs its fuel consumption)
- Vehicle 1—N Expense
- User N—1 Role (role is an enum field on User for this scale; a separate Role table is unnecessary at hackathon scope)

---

## 3. State Machines

### 3.1 Vehicle Status

```
        register           dispatch trip           complete/cancel trip
 [ ]  ────────────► Available ───────────► On Trip ───────────────► Available
                       │  ▲                                          ▲
          create active│  │ maintenance                              │
          maintenance   │  │ completed                                │
                       ▼  │                                          │
                    In Shop ──────────────────────────────────────────┘
                       │
                 retire (manual)
                       ▼
                    Retired  (terminal — excluded from all pools)
```

### 3.2 Driver Status

```
 [ ] ──► Available ──dispatch──► On Trip ──complete/cancel──► Available
             │  ▲
   set Off Duty│  │ set back on duty
             ▼  │
          Off Duty

  (Suspended can be set from Available/Off Duty by Safety Officer;
   Suspended blocks trip assignment regardless of other state)
```

### 3.3 Trip Lifecycle

```
Draft ──dispatch (validated)──► Dispatched ──complete (odometer+fuel)──► Completed
  │                                  │
  └──cancel──► Cancelled ◄───cancel──┘
```

Validation gate before `Draft → Dispatched`:
- Vehicle.status == AVAILABLE
- Driver.status == AVAILABLE
- Driver.licenseExpiryDate >= today
- Driver.status != SUSPENDED
- Trip.cargoWeightKg <= Vehicle.maxLoadCapacityKg

If any check fails, dispatch is blocked and a specific inline error is shown (per wireframe: "Vehicle Capacity 500 kg / Cargo Weight 700 kg — capacity exceeded, dispatch blocked").

---

## 4. Screen-by-Screen Design (per wireframe)

| # | Screen | Key Elements | Primary Actions |
|---|---|---|---|
| 0 | Authentication (RBAC) | Email/password form, role selector (demo convenience), error states (invalid credentials, lockout after 5 attempts) | Sign in |
| 1 | Dashboard | KPI tiles (7 metrics), filters (vehicle type/status/region), Recent Trips table, Vehicle Status bar chart | Filter, drill into trip |
| 2 | Vehicle Registry | Searchable/filterable table, Add Vehicle modal | Add/Edit vehicle, filter by type/status |
| 3 | Drivers & Safety Profiles | Table with license expiry flags, safety score, status badges, toggle status | Add driver, flag expired license |
| 4 | Trip Dispatcher | Trip lifecycle stepper, Create Trip form (source/destination/vehicle/driver/cargo/distance), Live Board grouped by stage, inline validation errors | Create, Dispatch, Cancel, Complete |
| 5 | Maintenance | Log Service Record form, Service Log history table | Save record (auto-flips vehicle to In Shop), Complete/Close |
| 6 | Fuel & Expense Management | Fuel Logs table, Other Expenses table, computed total | Log Fuel, Add Expense |
| 7 | Reports & Analytics | KPI tiles (fuel efficiency, utilization, op cost, ROI), Monthly Revenue chart, Top Costliest Vehicles bar chart | Export CSV, filter by date range |
| 8 | Settings & RBAC | Depot/currency/distance-unit settings, RBAC matrix editor | Save changes |

All authenticated screens share: left sidebar nav (scoped by role), top search bar, user badge with role tag (matches "Dispatcher / RF" badge pattern in wireframe).

---

## 5. RBAC Enforcement Design

- Role stored on session/JWT at login.
- **Route-level guard**: Next.js middleware checks role before allowing navigation to a restricted route (e.g., Dispatcher hitting `/settings` → redirected).
- **UI-level guard**: sidebar renders only permitted links per the matrix in PRD §8.
- **API-level guard**: every server action re-checks role server-side — this is the actual security boundary; UI hiding is UX only, not enforcement.

---

## 6. Key Interaction: Trip Dispatch Validation Flow

1. Dispatcher fills Create Trip form → selects Vehicle (query filters to `status = AVAILABLE`), Driver (query filters to `status = AVAILABLE AND licenseExpiryDate >= today AND status != SUSPENDED`).
2. On "Dispatch" click, server action re-validates all conditions (never trust client-filtered dropdowns alone, since data can go stale between load and submit).
3. If cargo weight > vehicle capacity → return validation error, trip stays in `Draft`, no status changes committed.
4. If valid → transaction: update Trip.status = DISPATCHED, Vehicle.status = ON_TRIP, Driver.status = ON_TRIP (all three writes wrapped in a single DB transaction to avoid partial state).

---

## 7. Analytics Calculations

- **Fuel Efficiency** = Total Distance (km) / Total Fuel Consumed (liters), per vehicle or fleet-wide.
- **Fleet Utilization (%)** = (Vehicles On Trip / Total Active Vehicles) × 100.
- **Operational Cost** (per vehicle) = SUM(FuelLog.cost) + SUM(MaintenanceLog.cost).
- **Vehicle ROI** = (Revenue − (Maintenance + Fuel)) / Acquisition Cost.
  - *Revenue* is not explicitly modeled in the spec — recommend adding a simple `revenuePerTrip` or flat trip billing field on Trip (even a manually entered value) so ROI has a numerator; flag this as a design decision to confirm with the team before build (see Open Questions).

---

## 8. Visual / UI Design Direction

- Clean, dashboard-style layout — dense data tables, colored status badges (green=Available/Completed, blue=On Trip/Dispatched, orange=In Shop/Draft, red=Retired/Suspended/Cancelled), consistent with the wireframe's badge coloring.
- Left sidebar navigation, fixed; top bar with global search + user/role badge.
- Chart palette: 2–3 accent colors max, consistent across Dashboard and Analytics.
- Optional dark mode (bonus): CSS variables for background/surface/text/accent so toggling is a single class swap on `<html>`.

---

## 9. Open Design Questions (flag to team before/при build)

1. **Revenue source for ROI** — is trip revenue entered manually per trip, or derived from a rate table (e.g., ₹/km)? Recommend: add a simple manual `revenue` field on Trip for hackathon scope.
2. **Region field** — vehicles have a `region` used for dashboard filtering; confirm whether this is free text or a fixed list (fixed list is faster to build a filter for).
3. **Multiple drivers/vehicles per trip** — spec implies 1:1; confirming no multi-leg trips are in scope.
